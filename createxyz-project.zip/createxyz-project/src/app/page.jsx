"use client";
import React from "react";

function MainComponent() {
  return (
    <div>
      <header className="bg-transparent w-full p-4 flex items-center justify-between">
        <div className="flex items-center">
          <div className="grid grid-cols-10 gap-2 p-2">
            <img
              src="path/to/team1.svg"
              alt="team 1 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team2.svg"
              alt="team 2 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team3.svg"
              alt="team 3 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team4.svg"
              alt="team 4 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team5.svg"
              alt="team 5 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team6.svg"
              alt="team 6 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team7.svg"
              alt="team 7 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team8.svg"
              alt="team 8 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team9.svg"
              alt="team 9 logo"
              className="w-[20px] h-[20px]"
            />
            <img
              src="path/to/team10.svg"
              alt="team 10 logo"
              className="w-[20px] h-[20px]"
            />
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <select name="language" className="text-black p-2 rounded">
            <option value="en">English</option>
            <option value="es">Español</option>
          </select>
          <button className="flex items-center space-x-2">
            <i className="fas fa-user-circle"></i> <span>Login</span>
          </button>
        </div>
      </header>
      <div className="w-full p-4 bg-white shadow">
        <nav className="flex justify-center space-x-4 text-sm font-bold">
          <a href="#institucional" className="font-roboto">
            ESL Institutional
          </a>
          <a href="#withsport" className="font-roboto">
            ESL with sport
          </a>
          <a href="#wheretowatch" className="font-roboto">
            Where to watch ESL
          </a>
          <a href="#group" className="font-roboto">
            ESL Group
          </a>
        </nav>
      </div>
      <div className="w-full p-4 bg-[#F7F7F7] shadow">
        <nav className="flex justify-center space-x-4 text-sm font-bold">
          <a href="#content" className="font-roboto">
            Fútbol Femenino
          </a>
          <a href="#fantasy" className="font-roboto">
            Fantasy
          </a>
          <a href="#stats" className="font-roboto">
            Beyond Stats
          </a>
          <a href="#calendar" className="font-roboto">
            Calendar
          </a>
          <a href="#fanzone" className="font-roboto">
            Fan Zone
          </a>
          <a href="#videos" className="font-roboto">
            Videos
          </a>
          <a href="#news" className="font-roboto">
            News
          </a>
          <a href="#statistics" className="font-roboto">
            Statistics
          </a>
          <a href="#galleries" className="font-roboto">
            Photo Galleries
          </a>
        </nav>
      </div>
      <div className="text-center bg-white py-2 border-b border-gray-300">
        <a
          href="#sports"
          className="px-4 py-2 bg-red-500 text-white rounded-full font-roboto"
        >
          ESL EA SPORTS
        </a>
        <span className="text-gray-500 mx-4 font-roboto">|</span>
        <a href="#hypermotion" className="px-4 py-2 text-gray-800 font-roboto">
          ESL HYPERMOTION
        </a>
        <span className="text-gray-500 mx-4 font-roboto">|</span>
        <a href="#ligaf" className="px-4 py-2 text-gray-800 font-roboto">
          Youth
        </a>
      </div>
      <main className="p-4 bg-[#F7F7F7]">
        <section>
          <h2 className="text-2xl font-bold mb-4 font-roboto">NEXT MATCHES</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { fixture: "", homeGoals: 7, awayGoals: 0 },
              { fixture: "", homeGoals: 1, awayGoals: 1 },
              { fixture: "", homeGoals: 0, awayGoals: 2 },
              { fixture: "", homeGoals: 6, awayGoals: 1 },
            ].map((match, index) => (
              <div
                key={index}
                className="border rounded-lg overflow-hidden bg-white"
              >
                <div className="p-4">
                  <div className="flex justify-between items-center">
                    <div className="text-lg font-bold font-roboto">
                      {match.homeGoals}
                    </div>
                    <div className="text-sm font-roboto text-gray-500">
                      <FixtureDisplay fixture={match.fixture} />
                    </div>
                    <div className="text-lg font-bold font-roboto">
                      {match.awayGoals}
                    </div>
                  </div>
                </div>
                <div className="flex justify-center space-x-2 text-sm text-gray-500 p-4 font-roboto">
                  <span>Compare</span>
                  <span>Result</span>
                  <span>TV</span>
                </div>
                <div className="p-4 bg-red-500 text-white text-center font-roboto">
                  Where to watch ESL
                </div>
              </div>
            ))}
          </div>
          <div className="text-right mt-4">
            <a href="#allmatches" className="text-red-600 font-roboto">
              SEE ALL RESULTS
            </a>
          </div>
        </section>

        <section className="mt-8">
          <h2 className="text-2xl font-bold mb-4 font-roboto">
            LATEST ESL NEWS
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="col-span-1 p-4 bg-white rounded-lg overflow-hidden">
              <img
                src="path/to/news1.jpg"
                alt="Latest news 1"
                className="w-full h-[200px] object-cover"
              />
              <h3 className="text-lg font-bold mt-2 font-roboto">
                Latest News Headline
              </h3>
            </div>
            <div className="col-span-1 p-4 bg-white rounded-lg overflow-hidden">
              <img
                src="path/to/news2.jpg"
                alt="Latest news 2"
                className="w-full h-[200px] object-cover"
              />
              <h3 className="text-lg font-bold mt-2 font-roboto">
                Latest News Headline
              </h3>
            </div>
            <div className="col-span-1 p-4 bg-white rounded-lg overflow-hidden">
              <img
                src="path/to/news3.jpg"
                alt="Latest news 3"
                className="w-full h-[200px] object-cover"
              />
              <h3 className="text-lg font-bold mt-2 font-roboto">
                Latest News Headline
              </h3>
            </div>
          </div>
          <div className="text-right mt-4">
            <a href="#allnews" className="text-red-600 font-roboto">
              SEE ALL NEWS
            </a>
          </div>
        </section>

        <section className="mt-8">
          <h2 className="text-2xl font-bold mb-4 font-roboto">
            STADIUM ATTENDANCES
          </h2>
          <div className="flex flex-col items-center bg-white p-4 rounded-lg">
            <div className="text-4xl font-bold text-red-500 font-roboto"></div>
            <span className="font-roboto">Season 2023/2024</span>
            <div className="flex space-x-8 mt-4">
              {[
                { value: "258,880", label: "Increase" },
                { value: "1.67%", label: "Growth" },
              ].map((item, index) => (
                <div key={index} className="text-center font-roboto">
                  <div className="text-xl font-bold">{item.value}</div>
                  <span>{item.label}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default MainComponent;