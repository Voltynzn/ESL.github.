"use client";
import React from "react";


export default function Index() {
  return (function FixtureDisplay({ fixture }) {
  return (
    <div className="text-sm font-roboto text-gray-500">
      {fixture}
    </div>
  );
}

function FixtureDisplayStory() {
  return (
    <div>
      <FixtureDisplay fixture="Team A vs Team B" />
      <FixtureDisplay fixture="Team C vs Team D" />
      <FixtureDisplay fixture="Team E vs Team F" />
    </div>
  );
});
}